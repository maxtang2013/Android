package com.example.maxtang.criminalintent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.UUID;

/**
 * Created by maxtang on 16/4/12.
 */
public class Crime {
    private static String FIELD_ID = "id";
    private static String FIELD_TITLE = "title";
    private static String FIELD_DATE = "date";
    private static String FIELD_IS_SOVLED = "solved";

    public UUID getId() {
        return id;
    }

    private UUID id;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private String title;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    private Date date;

    public boolean isSolved() {
        return solved;
    }

    public void setSolved(boolean solved) {
        this.solved = solved;
    }

    private boolean solved;

    public Crime() {
        id = UUID.randomUUID();
        date = new Date();
    }

    public Crime(JSONObject object) {
        try {
            id = UUID.fromString(object.getString(FIELD_ID));
            title = object.getString(FIELD_TITLE);
            solved = object.getBoolean(FIELD_IS_SOVLED);
            date = new Date(object.getLong(FIELD_DATE));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String toString() {
        return title;
    }

    public JSONObject toJSON() {
        JSONObject object = new JSONObject();
        try {
            object.put(FIELD_ID, id.toString());
            object.put(FIELD_DATE, date.getTime());
            object.put(FIELD_IS_SOVLED, solved);
            object.put(FIELD_TITLE, title);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return object;
    }
}
