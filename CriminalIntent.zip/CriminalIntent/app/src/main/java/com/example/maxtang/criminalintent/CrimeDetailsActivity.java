package com.example.maxtang.criminalintent;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;

import java.util.ArrayList;
import java.util.UUID;

import layout.DetailFragment;


public class CrimeDetailsActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceData) {
        super.onCreate(savedInstanceData);

        mCrimes = CrimeLab.getInstance(this).getmCrimes();

        View view = getLayoutInflater().inflate(R.layout.activity_crime_details, null);
        ViewPager viewPager = (ViewPager)view.findViewById(R.id.viewPager);
        Toolbar toolbar = (Toolbar)view.findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        setContentView(view);

        FragmentManager fm = getSupportFragmentManager();
        viewPager.setAdapter(new FragmentStatePagerAdapter(fm) {
            @Override
            public Fragment getItem(int position) {
                Crime crime = mCrimes.get(position);
                DetailFragment fragment = DetailFragment.newInstance(crime.getId());
                return fragment;
            }

            @Override
            public int getCount() {
                return mCrimes.size();
            }
        });


        UUID uuid = (UUID) getIntent().getSerializableExtra(DetailFragment.EXTRA_KEY_UUID);
        for (int i = 0; i < mCrimes.size(); ++i) {
            Crime c = mCrimes.get(i);
            if (c.getId().equals(uuid))
            {
                Log.d("Hi", "lo");
                viewPager.setCurrentItem(i);
                break;
            }
        }
        Log.d("Hi", uuid.toString());
    }

    private ArrayList<Crime> mCrimes;
}
