package com.example.maxtang.criminalintent;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.UUID;

import layout.DetailFragment;

/**
 * A placeholder fragment containing a simple view.
 */
public class CrimeListFragment extends ListFragment {
    private static String KEY_IS_SUBTITLE_VISIBLE = "IsSubtitleVisible";
    @Override
    public void onCreate(Bundle savedInsanceData) {
        super.onCreate(savedInsanceData);
        getActivity().setTitle(R.string.crimes_title);

        setHasOptionsMenu(true);

        mCrimes = CrimeLab.getInstance(getActivity()).getmCrimes();

        CrimeAdapter adapter = new CrimeAdapter(mCrimes);
        setListAdapter(adapter);
    }

    @Override
    public void onSaveInstanceState(Bundle data) {
        super.onSaveInstanceState(data);
        data.putBoolean(KEY_IS_SUBTITLE_VISIBLE, mIsSubtitleVisible);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup group, Bundle savedInstanceData) {
        View v = super.onCreateView(inflater, group, savedInstanceData);
        if (savedInstanceData != null && savedInstanceData.containsKey(KEY_IS_SUBTITLE_VISIBLE)) {
            mIsSubtitleVisible = savedInstanceData.getBoolean(KEY_IS_SUBTITLE_VISIBLE);
            updateSubtitleVisibility();
        }
        ListView listView = (ListView) v.findViewById(android.R.id.list);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);

        listView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {

            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                getActivity().getMenuInflater().inflate(R.menu.context_actions, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                boolean handled = false;
                switch (item.getItemId()) {
                    case R.id.menu_item_delete:
                        CrimeAdapter adapter = (CrimeAdapter) getListAdapter();
                        CrimeLab crimeLab = CrimeLab.getInstance(getActivity());
                        for (int i = adapter.getCount() - 1; i >= 0; --i) {
                            if (getListView().isItemChecked(i)) {
                                crimeLab.removeCrime(adapter.getItem(i));
                            }
                        }
                        mode.finish();
                        adapter.notifyDataSetChanged();
                        handled = true;
                        break;

                    default:
                        break;
                }
                return handled;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {

            }
        });
        return v;
    }


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        Crime crime = mCrimes.get(position);
        startDetailActivity(crime.getId());
    }


    private class CrimeAdapter extends ArrayAdapter<Crime> {
        public CrimeAdapter(ArrayList<Crime> crimes) {
            super(getActivity(), 0, crimes);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = getActivity().getLayoutInflater().inflate(R.layout.crime_list_item, null);
            }

            Crime crime = getItem(position);
            TextView titleText = (TextView) convertView.findViewById(R.id.item_title);
            TextView dateText = (TextView) convertView.findViewById(R.id.item_date);
            CheckBox checkBox = (CheckBox) convertView.findViewById(R.id.item_checkbox_solved);

            titleText.setText(crime.getTitle());
            dateText.setText(crime.getDate().toString());
            checkBox.setChecked(crime.isSolved());

            return convertView;
        }
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_crime_list, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        boolean handled = false;
        switch (item.getItemId()) {
            case R.id.menu_item_new_crime:
                addNewCrime();
                handled = true;
                break;

            case R.id.menu_item_show_subtitle:
                mIsSubtitleVisible = !mIsSubtitleVisible;
                updateSubtitleVisibility();
                if (mIsSubtitleVisible) {
                    item.setTitle(R.string.hide_subtitle);
                } else {
                    item.setTitle(R.string.show_subtitle);
                }
                handled = true;
                break;
        }

        return handled || super.onOptionsItemSelected(item);
    }

    private void updateSubtitleVisibility() {
        ActionBar bar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        if (mIsSubtitleVisible) {
            bar.setSubtitle(R.string.subtitle);
        } else {
            bar.setSubtitle(null);
        }
    }

    private void addNewCrime() {
        UUID id = CrimeLab.getInstance(getActivity()).newCrime();
        startDetailActivity(id);
    }

    private void startDetailActivity(UUID id) {
        Intent intent = new Intent(getActivity(), CrimeDetailsActivity.class);
        intent.putExtra(DetailFragment.EXTRA_KEY_UUID, id);
        startActivity(intent);
    }

    @Override
    public void onPause() {
        super.onPause();
        CrimeLab.getInstance(getActivity()).saveCrimes();
    }

    private boolean mIsSubtitleVisible;
    private ArrayList<Crime> mCrimes;
}
