package com.example.maxtang.criminalintent;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by maxtang on 16/4/16.
 */
public class CrimeSerializer {
    public void saveCrimeList(ArrayList<Crime> crimeList) throws IOException {
        OutputStream outputStream = null;
        outputStream = mContext.openFileOutput(DATA_FILE, MODE_PRIVATE);
        OutputStreamWriter writer = new OutputStreamWriter(new BufferedOutputStream(outputStream));
        JSONArray array = new JSONArray();
        for (Crime c : crimeList) {
            array.put(c.toJSON());
        }
        writer.write(array.toString());
        writer.flush();
        writer.close();
    }

    public ArrayList<Crime> loadCrimeList() throws IOException, JSONException{
        BufferedReader reader = null;
        InputStream input = null;
        String line = null;
        StringBuilder jsonString = new StringBuilder();
        JSONTokener tokenizer = null;
        ArrayList<Crime> crimes = new ArrayList<>();

        input = mContext.openFileInput(DATA_FILE);
        reader = new BufferedReader(new InputStreamReader(input));
        while ((line = reader.readLine()) != null) {
            jsonString.append(line);
        }

        tokenizer = new JSONTokener(jsonString.toString());
        JSONArray array = (JSONArray)tokenizer.nextValue();
        for (int i = 0; i < array.length(); ++i) {
            JSONObject object = array.getJSONObject(i);
            Crime crime = new Crime(object);
            crimes.add(crime);
        }

        return crimes;
    }

    public CrimeSerializer(Context context) {
        mContext = context;
    }

    private static String DATA_FILE = "CrimeList";
    private Context mContext;
}
